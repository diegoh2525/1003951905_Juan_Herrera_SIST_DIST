/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.PersonaM;
/**
 *
 * @author jdher
 */
public class PersonaC {
    public void Agregar(String tipoDocumento, String numeroDocumento, String nombreCompleto, String direccionCorreo){
        //Objeto del modelo
        PersonaM personaM = new PersonaM();
        personaM.setTipoDocumento(tipoDocumento);
        personaM.setDocumento(numeroDocumento);
        personaM.setNombre(nombreCompleto);
        personaM.setEstadoCredito(estadoCredito);
        personaM.Agregar();
    }
    public void Eliminar(int idPersona){
        //Objeto del modelo
        PersonaM personaM = new PersonaM();
        personaM.setId(idPersona);
        personaM.Eliminar();
    }
    
    public List<Persona> ConsultarRegistro() {
        List<Persona> personas = new ArrayList<>();
        Persona persona = new Persona();
        ResultSet resultSet = (ResultSet) persona.Consultar();

        try {
            while (resultSet.next()) {
                Persona p = new Producto();
                p.setId(resultSet.getLong("id"));
                p.setTipoDocumento(resultSet.getString("tipoDocumento"));
                p.setDocumento(resultSet.getString("documento"));
                p.setNombre(resultSet.getDouble("nombre"));
                p.setEstadoCredito(resultSet.getLong("estadoCredito"));
                p.setValorCredito(resultSet.getBoolean("valorCredito"));
                // También puedes establecer otros campos si es necesario
                personas.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de excepciones según tu lógica
        } finally {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace(); // Manejo de excepciones según tu lógica
            }
        }

        return productos;
    }

    public List<Personas> ListarPersonas() {
        List<Persona> productos = new ArrayList<>();
        Persona persona = new Persona();
        ResultSet resultSet = (ResultSet) persona.Consultar();

        try {
            while (resultSet.next()) {
                Persona p = new Persona();
                p.setId(resultSet.getLong("id"));
                p.setNombre(resultSet.getString("nombre"));
                personas.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de excepciones según tu lógica
        } finally {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace(); // Manejo de excepciones según tu lógica
            }
        }

        return personas;
    }
}
